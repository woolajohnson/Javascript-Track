const stringlib = require("./stringlib");
const stringlib1 = new stringlib();
console.log(stringlib1.concat("Village", "88"));
console.log(stringlib1.repeat("Ha", 3));
console.log(stringlib1.toString(7));
console.log(stringlib1.charAt("Hero", 2));
