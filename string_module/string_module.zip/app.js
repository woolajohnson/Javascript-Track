const stringlib = require("./stringlib");
console.log(stringlib().concat("Village", "88"));
console.log(stringlib().repeat("Ha", 4));
console.log(stringlib().toString(5));
console.log(stringlib().charAt("nice", 3));
